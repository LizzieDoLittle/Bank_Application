from django.contrib import admin
from .models import *
from django.shortcuts import redirect
from django.utils.safestring import mark_safe    
from django.urls import reverse


# Register your models here.
class CorporationAdmin(admin.ModelAdmin):
	list_display = ('corpid','shortname','longname','corpresassets')

class BankAccountAdmin(admin.ModelAdmin):
	list_display = ('balance','accountid','bankid')

class PersonAdmin(admin.ModelAdmin):
	list_display = ('perid','pwd')

class HireAdmin(admin.ModelAdmin):
	list_display = ('bankid','perid')
class BankAdmin(admin.ModelAdmin):
	list_display = ('bankid', 'manager')
class FeesAdmin(admin.ModelAdmin):
	list_display = ('bankid','accountid','fee')
admin.site.register(Corporation, CorporationAdmin)
admin.site.register(Person, PersonAdmin)
admin.site.register(BankAccount, BankAccountAdmin)
admin.site.register(Employee)
admin.site.register(Customer)
admin.site.register(BankUser)
admin.site.register(Workfor, HireAdmin)
admin.site.register(Bank, BankAdmin)
admin.site.register(InterestBearingFees)
