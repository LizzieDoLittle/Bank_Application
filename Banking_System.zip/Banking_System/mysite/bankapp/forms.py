from django import forms
from .models import *


#create forms here
class CreateCorporationForm(forms.ModelForm):

    class Meta:
        model = Corporation
        fields = ('corpid', 'shortname', 'longname', 'corpresassets')


class CreateEmployeeForm(forms.ModelForm):

    class Meta:
        model = Employee
        fields = ('perid', 'salary', 'payments', 'earned')

class CreateCustomerForm(forms.ModelForm):

	class Meta:
		model = Customer
		fields = ('perid',)

class CreateUserForm(forms.ModelForm):

	class Meta:
		model = BankUser
		fields = ('perid','taxid','birthdate','firstname','lastname','dtjoined','street','city','state','userzip')

class HireWorkerForm(forms.ModelForm):

	class Meta:
		model = Workfor
		fields = ('bankid','perid')

class ReplaceManagerFormSalary(forms.ModelForm):
	class Meta:
		model = Employee
		fields = ('salary',)

class ReplaceManagerFormBank(forms.ModelForm):
	class Meta:
		model = Workfor
		fields = ('bankid','perid')

class StopEmployeeForm(forms.Form):
	username = forms.CharField()


class StopCustomerForm(forms.ModelForm):
	class Meta:
		model = Customer
		fields = ('perid',)

class CreateFeeForm(forms.ModelForm):
	class Meta:
		model = InterestBearingFees
		fields = ('bankid','accountid','fee')

class TransactionForm(forms.ModelForm):
	class Meta:
		model = Checking
		fields = ('bankid','accountid','amount')


class HireForm(forms.ModelForm):
	class Meta:
		model = Workfor
		fields = ('bankid','perid')
class AccountForm(forms.ModelForm):
	class Meta:
		model = BankAccount
		fields = ('bankid','accountid','balance')