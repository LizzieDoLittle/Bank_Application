import django_tables2 as tables

class AccountTable(tables.Table):
    class Meta:
        model = BankAccount