from django.urls import path

from . import views
from django.urls import path, include

urlpatterns = [
    path('', views.index, name='index'),
    #path('create_bank/', views.create_bank, name='create_bank'),
   # path('create_corporation/', views.create_corporation, name='create_corporation'),
    path('create_employee/', views.create_employee, name='create_employee'),
    path('create_customer/', views.create_customer, name='create_customer'),
    path('create_user/', views.create_user, name='create_user'),
    path('hire_worker/', views.hire_worker, name='hire_worker'),
    path('replace_manager/', views.replace_manager, name='replace_manager'),
    path('manage_accounts/', views.manage_accounts, name='manage_accounts'),
    path('manage_accounts_customer/', views.manage_accounts_customer, name='manage_accounts_customer'),
    path('create_fee/', views.create_fee, name='create_fee'),
    path('manage_overdraft_policies/', views.manage_overdraft_policies, name='manage_overdraft_policies'),
    path('make_deposit/', views.make_deposit, name='make_deposit'),
    path('make_withdrawal/', views.make_withdrawal, name='make_withdrawal'),
    path('make_account_transfer/', views.make_account_transfer, name='make_account_transfer'),
    path('pay_employee/', views.pay_employee, name='pay_employee'),
    path('display_account_stats/', views.display_account_stats, name='display_account_stats'),
    path('display_bank_stats/', views.display_bank_stats, name='display_bank_stats'),
    path('display_corporation_stats/', views.display_corporation_stats, name='display_corporation_stats'),
    path('display_customer_stats/', views.display_customer_stats, name='display_customer_stats'),
    path('display_employee_stats/', views.display_employee_stats, name='display_employee_stats'),
    path('manage_users/', views.manage_users, name='manage_users'),
    path('view_stats/', views.view_stats, name='view_stats'),
    path('stop_customer/', views.stop_customer, name='stop_customer'),
    path('stop_employee/', views.stop_employee, name='stop_employee'),
    path('manager_navigation/', views.manager_navigation, name='manager_navigation'),
    path('customer_navigation/', views.customer_navigation, name='customer_navigation'),



]

urlpatterns += [
    path('accounts/', include('django.contrib.auth.urls')),
]