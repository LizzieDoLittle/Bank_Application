from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import *
from django.template import loader
from .forms import *
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import permission_required
from django.views.generic import ListView


def index(request):
    return HttpResponse("Welcome to the Bank Application")

@permission_required('bankapp.admin_access')
def create_user(request):
    if request.method == "POST":
        create_user_form = CreateUserForm(request.POST)
        if create_user_form.is_valid():
            create_user_form.save()
            messages.success(request, ('Your employee was successfully added!'))
        else:
            messages.error(request, 'Error saving form')
        
        
        return redirect("create_user")
    create_user_form  = CreateUserForm()
    bankUser = BankUser.objects.all()
    return render(request=request, template_name="bankapp/create_user.html", context={'create_user_form':create_user_form,'bankUser':bankUser})


@permission_required('bankapp.admin_access')
def create_employee(request):
    if request.method == "POST":
        create_employee_form = CreateEmployeeForm(request.POST)
        if create_employee_form.is_valid():
            create_employee_form.save()
            messages.success(request, ('Your employee was successfully added!'))
        else:
            messages.error(request, 'Error saving form')
        
        
        return redirect("create_employee")
    create_employee_form  = CreateEmployeeForm()
    employee = Employee.objects.all()
    return render(request=request, template_name="bankapp/create_employee.html", context={'create_employee_form':create_employee_form,'employee':employee})

@permission_required('bankapp.admin_access')
def create_customer(request):
    if request.method == "POST":
        create_customer_form = CreateCustomerForm(request.POST)
        if create_customer_form.is_valid():
            create_customer_form.save()
            messages.success(request, ('Your customer was successfully added!'))
        else:
            messages.error(request, 'Error saving form')
        
        
        return redirect("create_customer")
    create_customer_form  = CreateCustomerForm()
    customer = Customer.objects.all()
    return render(request=request, template_name="bankapp/create_customer.html", context={'create_customer_form':create_customer_form,'customer':customer})

@permission_required('bankapp.manager_access')
def hire_worker(request): #workfor table
    if request.method == "POST":
        hire_worker_form = HireForm(request.POST)
        if hire_worker_form.is_valid():
            hire_worker_form.save()
            messages.success(request, ('New hire was successfully added!'))
        else:
            messages.error(request, 'Error saving form')
        return redirect("hire_worker")
    hire_worker_form  = HireForm()
    return render(request=request, template_name="bankapp/hire_worker.html", context={'hire_worker_form':hire_worker_form})

@permission_required('bankapp.admin_access')
def replace_manager(request): # Just use admin page to replace manager and update salary
    if request.method == "POST":
        replace_manager_form_bank = ReplaceManagerFormBank(request.POST)
        replace_manager_form_salary = ReplaceManagerFormSalary(request.POST)
        print("Hello world0")
        if replace_manager_form_bank.is_valid():# and replace_manager_form_bank.is_valid():
            print("Hello world1")
            replace_manager_form_bank.save()
            print("Hello world2")
            #managerid = Employee.objects.get(perid = replace_manager_form_bank.cleaned_data['manager'])
            #newsalary = replace_manager_form_salary.cleaned_data['salary']
            #managerid.salary = newsalary
            #managerid.save()

            messages.success(request, ('Manager stuff under construction!'))
        else:
            messages.error(request, 'Error saving form')
        return redirect("replace_manager")
    replace_manager_form_bank= ReplaceManagerFormBank()
    #replace_manager_form_salary= ReplaceManagerFormSalary()
    return render(request=request, template_name="bankapp/replace_manager.html", context={'replace_manager_form_bank':replace_manager_form_bank})

@permission_required('bankapp.admin_access')
def manage_accounts(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')
def create_fee(request):
    if request.method == "POST":
        create_fee_form = CreateFeeForm(request.POST)
        if create_fee_form.is_valid():
            create_fee_form.save()
            messages.success(request, ('Fee created!'))
        else:
            messages.error(request, 'Error saving form')
        return redirect("create_fee")
    create_fee_form  = CreateFeeForm()
    return render(request=request, template_name="bankapp/create_fee.html", context={'create_fee_form':create_fee_form})

@permission_required('bankapp.customer_access')
def manage_overdraft_policies(request): #skipped for now
    if request.method == "POST":
        create_fee_form = CreateFeeForm(request.POST)
        if create_fee_form.is_valid():
            create_fee_form.save()
            messages.success(request, ('Fee created!'))
        else:
            messages.error(request, 'Error saving form')
        return redirect("create_fee")
    create_fee_form  = CreateFeeForm()
    return render(request=request, template_name="bankapp/create_fee.html", context={'create_fee_form':create_fee_form})

@permission_required('bankapp.customer_access')
def manage_accounts_customer(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.customer_access')
def make_deposit(request): #skipped for now
    if request.method == "POST":
        transaction_form = TransactionForm(request.POST)
        if transaction_form.is_valid():
            # amount = Employee.objects.get(amount = transaction_form.cleaned_data['amount'], bankid = transaction_form.cleaned_data['bankid'], accountid = transaction_form.cleaned_data['accountid'])
            transaction_form.save()
            messages.success(request, ('Transaction created!'))
        else:
            print("error saving form")
        return redirect("make_deposit")
    transaction_form  = TransactionForm()
    return render(request=request, template_name="bankapp/make_deposit.html", context={'transaction_form':transaction_form})

@permission_required('bankapp.customer_access')
def make_withdrawal(request): #skipped for now
    if request.method == "POST":
        transaction_form = TransactionForm(request.POST)
        if tansaction_form.is_valid():
            transaction_form.save()
            messages.success(request, ('Transaction created!'))
        else:
            messages.error(request, 'Error saving form')
        return redirect("make_withdrawal")
    transaction_form  = TransactionForm()
    return render(request=request, template_name="bankapp/make_deposit.html", context={'transaction_form':transaction_form})

@permission_required('bankapp.customer_access')
def make_account_transfer(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.manager_access')
def pay_employee(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')
def display_account_stats(request):
    table = AccountForm(BankAccount.objects.all())
    return render(request, "bankapp/display_account_stats.html", {
        "table": table
    })
@permission_required('bankapp.admin_access')
def display_bank_stats(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')
def display_corporation_stats(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')
def display_customer_stats(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')

def display_employee_stats(request): #skipped for now
    return HttpResponse("Under construction")

@permission_required('bankapp.admin_access')
def manage_users(request):
    return render(request=request, template_name="bankapp/manage_users.html")

@permission_required('bankapp.admin_access')
def view_stats(request):
    return render(request=request, template_name="bankapp/view_stats.html")

@permission_required('bankapp.manager_access')
def manager_navigation(request):
    return render(request=request, template_name="bankapp/manage_navigation.html")

@permission_required('bankapp.admin_access')
def stop_employee(request): #accessed via admin page
    if request.method == "POST":
        stop_employee_form = StopEmployeeForm(request.POST)
        if stop_employee_form.is_valid():
            employee = Employee.objects.get(username=stop_employee_form.cleaned_data['username'])
            if employee is not None:
                employee.delete()
                return redirect('stop_employee')
            else:
               ## Send some error messgae
                messages.success(request, ('Under construction: stopping employee role?'))
    else:
        stop_employee_form = StopEmployeeForm()

    context = {'stop_employee_form':stop_employee_form}
    return render(request,'bankapp/stop_employee.html', context)        

@permission_required('bankapp.admin_access')
def stop_customer(request):
    if request.method == "POST":
        stop_customer_form = StopCustomerForm(request.POST)
        if stop_customer_form.is_valid():
            # stop_employee_form.delete()
            messages.success(request, ('Under construction: stopping employee role?'))
        else:
            messages.error(request, 'Error saving form')
        
        
        return redirect("stop_employee")
    stop_customer_form  = StopCustomerForm()
    return render(request=request, template_name="bankapp/stop_customer.html", context = {"stop_customer_form":stop_customer_form})

@permission_required('bankapp.customer_access')
def customer_navigation(request):
    return render(request=request, template_name="bankapp/customer_navigation.html")
    
